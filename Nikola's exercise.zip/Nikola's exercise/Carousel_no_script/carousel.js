let imgWrapper = document.querySelector(".imageWrapper");
let navWrapper = document.querySelector(".navigationWrapper");
let numberOfImages = 4;
let imgName = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.webp",
]

//adding the img tags html
function addImages(numberOfImages) {
    for (var i = 0; i < numberOfImages; i++) {
        imgWrapper.innerHTML = imgWrapper.innerHTML + "<img>";
    }
    return imgWrapper;
}

//adding the dots in the carousel
function addDots(numberOfImages) {
    for (var i = 0; i < numberOfImages; i++) {
        navWrapper.innerHTML = navWrapper.innerHTML + "<div class=\"navigationDot\">";
    }
    return navWrapper;
}

//adding the attributes to the img tags
function addAttributes(numberOfImages) {
    for (var i = 0; i < numberOfImages; i++) {
        img[i].setAttribute('src', 'images/' + imgName[i]);
        img[i].classList.add('isHidden');
        img[0].classList.remove('isHidden');
        img[i].classList.add('displayImage');
    }
}

addDots(numberOfImages);
addImages(numberOfImages);
let img = document.querySelectorAll("img");
addAttributes(numberOfImages);
let dots = document.querySelectorAll(".navigationDot");

function state(index){
     dots[index].addEventListener("click", function(){
        for (var i = 0; i < numberOfImages; i++) {
            img[i].classList.add('isHidden');
        }
         img[index].classList.remove("isHidden");
     });
 }

for (i = 0; i < numberOfImages; i++) {
    state(i);
}

function showSlide(index){
       for (var i = 0; i < numberOfImages; i++) {
           img[i].classList.add('isHidden');
       }
        img[index].classList.remove("isHidden");
}

//var timer = setInterval(showSlide(i), 5000);

//for (i = 0; i < numberOfImages; i++) {
//    setInterval(showSlide(i), 5000);
//}




















